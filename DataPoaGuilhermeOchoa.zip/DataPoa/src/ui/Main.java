package ui;
public interface Main {
    public static void main(String[] args) {
        Aplicacao app = new Aplicacao();
        app.executa();
        
    }
}
