package ACMEFinancas;

public class Main {

	public static void main(String[] args) {
		ACMEFinancas acmeFinancas = new ACMEFinancas();
		acmeFinancas.inicializa();
		acmeFinancas.executa();
	}

}
