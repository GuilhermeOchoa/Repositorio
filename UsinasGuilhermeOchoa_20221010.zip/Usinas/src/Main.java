
public class Main {

	public static void main(String[] args) {
	ACMEEnergy acme = new ACMEEnergy();
		//acme.inicializa();
		acme.executa();
	}
}