package util;
import controller.ACMESpace;

public class Main {
    public static void main(String[] args) {
        
        ACMESpace acmeSpace = new ACMESpace();
        acmeSpace.executa();
        
    }
}