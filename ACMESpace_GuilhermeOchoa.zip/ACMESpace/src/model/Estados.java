package model;

public enum Estados {
    PENDENTE, TRANSPORTANDO, CANCELADO,
    FINALIZADO;
}

