package model;

public enum Combustiveis {
   NUCLEAR, ION;    
}
